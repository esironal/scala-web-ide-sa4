class Test_2 {
  
  def Test_2() {
    println("test 2 complete")
  }

}