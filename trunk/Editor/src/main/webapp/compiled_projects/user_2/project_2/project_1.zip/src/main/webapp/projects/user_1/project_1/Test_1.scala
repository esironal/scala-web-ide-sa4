class Test_1 {
  
  def test_1() {
    println("test 1 complete")
  }

}